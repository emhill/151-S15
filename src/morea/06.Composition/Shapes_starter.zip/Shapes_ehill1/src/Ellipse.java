import java.awt.Color;
import java.awt.Graphics;


public class Ellipse {

	private int x;
	private int y;
	private int widthRadius;
	private int heightRadius;
	private Color fillColor;
	private Color outlineColor;
	
	public Ellipse() {
		this(250, 250, 50, 100, Color.BLUE, Color.BLACK);
	}
	
	public Ellipse(int x, int y, int rw, int rh, Color c) {
		this(x, y, rw, rh, c, c);
	}
	
	public Ellipse(int x, int y, int rw, int rh, Color c, Color o) {
		this.x = x;
		this.y = y;
		widthRadius = rw;
		heightRadius = rh;
		fillColor = c;
		outlineColor = o;
	}
	
	public void draw(Graphics page) {
		System.out.println("Cirlce.draw");
		page.setColor(fillColor);
		page.fillOval(x-widthRadius, y-heightRadius, 2 * widthRadius, 2 * heightRadius);
		page.setColor(outlineColor);
		page.drawOval(x-widthRadius, y-heightRadius, 2 * widthRadius, 2 * heightRadius);
	}
	
	public int getHeightRadius() {
		return heightRadius;
	}
	
	public void setHeightRadius(int r) {
		heightRadius = r;
	}
	
	public int getWidthRadius() {
		return widthRadius;
	}
	
	public void setWidthRadius(int r) {
		widthRadius = r;
	}
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}
	
	public Color getOutlineColor() {
		return outlineColor;
	}
	
	public void setOutlineColor(Color o) {
		outlineColor = o;
	}
	
	public double getArea() {
		return widthRadius * heightRadius * Math.PI;
	}
	
	// 2 pi sqrt( a^2 + b^2 / 2 )
	public double getPerimeter() {
		double d = widthRadius * widthRadius + heightRadius * heightRadius;
		return 2 * Math.PI * Math.sqrt(d / 2);
	}

	public static void main(String[] args) {
		System.out.println("Circle main");
		Ellipse c = new Ellipse(50, 50, 100, 50, Color.MAGENTA);
		//c.setRadius(25);
		System.out.println("The radius is: " + c.getWidthRadius() + " and " +
							c.getHeightRadius());
		System.out.println("The area is: " + c.getArea());
		System.out.println("The perimeter is: " + c.getPerimeter());
	}

}
