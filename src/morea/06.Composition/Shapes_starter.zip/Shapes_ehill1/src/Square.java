import java.awt.Color;


public class Square extends Rectangle {
	public Square(int x, int y, int s, Color f, Color o) {
		super(x, y, s, s, f, o);
	}
	
	public Square(int x, int y, int s, Color f) {
		this(x, y, s, f, f);
	}
	
	public Square() {
		this(50, 50, 100, Color.BLUE);
	}
	
	public void setWidth(int w) {
		super.setWidth(w);
		super.setHeight(w);
	}
	
	public void setHeight(int w) {
		super.setWidth(w);
		super.setHeight(w);
	}
	
	public static void main(String[] args) {
		Square s = new Square();
		System.out.println("Area: " + s.getArea());
		System.out.println("Perimeter: " + s.getPerimeter()); 

	}
}
