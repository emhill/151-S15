import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Picture extends JPanel {
	
	private Circle circle;
	private Circle circle2;
	private Triangle triangle;
	private Triangle triangle2;
	private Rectangle rect;
	private Square square;
	private Ellipse oval;
	
	public Picture() {
		System.out.println("Picture Constructor");
		circle = new Circle();
		circle.setOutlineColor(Color.MAGENTA);
		circle2 = new Circle(100, 100, 100, Color.cyan, Color.PINK);
		oval = new Ellipse();
		oval.setFillColor(Color.YELLOW);
		triangle = new Triangle();
		triangle.setX(circle.getX());
		triangle.setY(circle.getY() - 
				(circle.getRadius() + triangle.getHeight()));
		triangle2 = new Triangle(150,150,150, 100, Color.PINK, Color.BLACK);
		rect = new Rectangle();
		rect.setY(300);
		square = new Square();
		square.setFillColor(Color.MAGENTA);
		square.setX(250);
		square.setY(250);
	}
	
	public void paintComponent(Graphics page) {
		System.out.println("Picture.paintComponent()");
		circle2.draw(page);
		square.draw(page);
		rect.draw(page);
		circle.draw(page);
		triangle.draw(page);
		triangle2.draw(page);
		oval.draw(page);
	}
	
	public static void main(String[] args)
	{
		System.out.println("Picture main");
		JFrame frame = new JFrame("Picture using Shapes");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
		JPanel panel = new Picture();
		panel.setPreferredSize(new Dimension(500,500));
		
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
	}


	
	
}
