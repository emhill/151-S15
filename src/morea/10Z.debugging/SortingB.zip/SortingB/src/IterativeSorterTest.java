import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Bare bones junit test suite for IterativeSorter
 * Every method is a test case - you should only have 1 assert in each method
 * To run, right click the class and select "Run As > Junit Test"
 * 
 * For more information about how to verify output is correct, see
 * http://www.junit.org/apidocs/org/junit/Assert.html
 * 
 * Complete for Testing HW
 * 
 * @author EmilyHill
 *
 */

public class IterativeSorterTest {
	
	@Test
	public void testSortBasic() {
		int[] unsorted = {5, 67, 12, 20};
		int[] sorted   = {5, 12, 20, 67};
		IterativeSorter is = new IterativeSorter(unsorted);
		int[] a = is.sort();
		assertArrayEquals(sorted, a);
	}
	
	@Test
	public void testSortDefault() {
		int[] unsorted = {0};
		int[] sorted   = {0};
		IterativeSorter is = new IterativeSorter(unsorted);
		int[] a = is.sort();
		assertArrayEquals(sorted, a);
	}

}
