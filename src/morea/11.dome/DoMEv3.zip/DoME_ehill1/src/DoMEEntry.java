public interface DoMEEntry {

	/**
	 * Enter a comment for this DVD.
	 * @param comment The comment to be entered.
	 */
	public void setComment(String comment);

	/**
	 * @return The comment for this DVD.
	 */
	public String getComment();

	/**
	 * Set the flag indicating whether we own this DVD.
	 * @param ownIt true if we own the DVD, false otherwise.
	 */
	public void setOwn(boolean ownIt);

	/**
	 * @return true if we own a copy of this DVD.
	 */
	public boolean getOwn();

	public void print();

}