public abstract class Item implements DoMEEntry {

	protected String title;
	protected int playingTime;
	protected boolean gotIt;
	protected String comment;

	public Item(String theTitle, int time) {
		title = theTitle;
        playingTime = time;
        gotIt = false;
        comment = "<no comment>";
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#setComment(java.lang.String)
	 */
	@Override
	public void setComment(String comment) {
	    this.comment = comment;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#getComment()
	 */
	@Override
	public String getComment() {
	    return comment;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#setOwn(boolean)
	 */
	@Override
	public void setOwn(boolean ownIt) {
	    gotIt = ownIt;
	}

	/* (non-Javadoc)
	 * @see DoMEEntry#getOwn()
	 */
	@Override
	public boolean getOwn() {
	    return gotIt;
	}
	
	public abstract String getSpecificType();
	public abstract void printSpecificInfo();
	
    /* (non-Javadoc)
	 * @see DoMEEntry#print()
	 */
    @Override
	public void print()
    {
        System.out.print(getSpecificType() + ": " + title + " (" + playingTime + " mins)");
        if(gotIt) {
            System.out.println("*");
        }
	else {
            System.out.println();
        }
        //System.out.println("    " + director);
        printSpecificInfo();
        System.out.println("    " + comment);
    }

}